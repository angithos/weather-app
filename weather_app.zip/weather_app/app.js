const express=require("express");
const https=require("https");
const bodyParser=require("body-parser");
const app=express();

app.use(bodyParser.urlencoded({extended:true}));
app.get("/",function(req,res){
res.sendFile(__dirname+"/index.html");
})

app.post("/",function(req,res){
  const query=req.body.cityName;
  const count=req.body.countryName;
  let url="https://api.openweathermap.org/data/2.5/weather?q="+query+","+count+"&appid=752717bdba9261251218d373a447b1e7&units=metric";

  https.get(url,function(response){

    response.on("data",function(data){

      const weatherData=JSON.parse(data);
      var icon=weatherData.weather[0].icon;
      var i_url="http://openweathermap.org/img/wn/"+icon+"@2x.png"
      var city=weatherData.name;
      var country=weatherData.sys.country;
      var temp =weatherData.main.temp;
      var feelslike=weatherData.main.feels_like;
      var cloud=weatherData.weather[0].description;

      res.write("<h1>it is "+temp+" degress celcius in "+city+","+country+"</h1>");
      res.write("<p> it feels "+feelslike+" and there is "+cloud+"</p>");
      res.write("<img src=" +i_url + ">");
      res.send();
     })
  })
})


app.listen("3000",function(){
  console.log("server running at port 3000");
})
